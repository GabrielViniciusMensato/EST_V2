COMO RODAR O PROJETO BAIXADO

Instalar todas as dependencias indicada pelo package.json
### npm install

Rodar o projeto
### node app.js

SEQUENCIA PARA CRIAR O PROJETO
Criar o arquivo package
### npm init

Instalar o MySQL
### npm install --save mysql2

Instalar a dependência de forma global, "-g' significa globalmente. Executar o comando através do prompt de comando, exceutar somente se nunca instalou a dependência na máquina, após instalar, reiniciar o PC. 
### npm install -g nodemon

Instalar a depednência como desenvolvedor para reiniciar o servidor sempre que houver alteração no código fonte.
### npm install --save-dev nodemon 

Rodar o projeto usando o nodemon
### nodemon app.js

Gerencia as requisições e rotas
### npm install express

Acessar o projeto no navegador
### http://localhost:8080

É uma biblioteca de Javascript que facilita o gerenciamento de banco de dados Sql 
### npm install --save sequelize 

Realizar submit para rota de cadastros
### npm instal axios 